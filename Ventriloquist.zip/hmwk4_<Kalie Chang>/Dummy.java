public class Dummy {
  private String name;
  private String specialAction;


  public Dummy (String name, String specialAction){
    this.name = name;
    this.specialAction = specialAction;

  }

  public String getName(){
    return name;
  }

  public void setName(String name){
    this.name = name;
  }

  public String getspecialAction(){
    return specialAction;
  }

  public void setspecialAction(String specialAction){
    this.specialAction = specialAction;
}
  //public String toString(){
    //return this.name + this.specialAction;
  public void doSpecialAction(){
   System.out.println(this.name + " " + this.specialAction);
  }

}
