public class Ventriloquist {
  private String name; //attributes
  private Dummy dummy;


  public Ventriloquist (String name, Dummy d){
    this.name = name;
    dummy = d;

  }

  public void setName(String name){
    this.name = name;
  }

  public String getName(){
    return this.name;
  }

  public String toString(){
    return this.name + " and the Brilliant " + this.dummy.getName();}

  public void pickUpDummy(Dummy d){
    this.dummy = d;
    System.out.println(this.name + " picks up " + d.getName());
  }
  public void ventriloquize(String thingToSay){
    System.out.println(this.dummy.getName() + " says " + thingToSay);
  }
  public void useSpecialAction(){ //calls dospecialAction
    this.dummy.doSpecialAction();
  }
  public void startDrinking(){
    System.out.println(this.name + " starts chugging a glass of water.");
  }
  public void drinkAndSpeak(String thingToSay){ //this way you don't have to type out everything
    this.startDrinking();
    this.ventriloquize(thingToSay);
    this.stopDrinking();
  }
  public void stopDrinking(){
    System.out.println(this.name + " stops chugging a glass of water.");
  }
  public void say(String whatToSay){
    System.out.println(this.name + " says, " + whatToSay);
  }
}
