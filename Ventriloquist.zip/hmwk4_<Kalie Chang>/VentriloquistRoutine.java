public class VentriloquistRoutine{

    public static void start(){
      Dummy dummy1 = new Dummy("Bob", "screams");
      Dummy dummy2 = new Dummy("Steve", "levitates");
      Ventriloquist stephanie = new Ventriloquist("Stephanie", dummy1);

      stephanie.pickUpDummy(dummy1);
      System.out.println("Introducing " + stephanie + "!");
      stephanie.say("'Good morning, " + dummy1.getName() + "!'");
      stephanie.ventriloquize("'It's not the morning, it's the afternoon! You're a bigger dummy than me!'");

      stephanie.useSpecialAction();

      stephanie.say("'You're rude, " + dummy1.getName() + "! I'm going to talk to " + dummy2.getName() + " now!'");
      stephanie.pickUpDummy(dummy2);
      stephanie.say("'Good afternoon, " + dummy2.getName() + "! How are you?'");
      stephanie.ventriloquize("'Why did you name me Steve? Bob keeps calling me Stupid Steve cause' I'm a dummy!'");
      stephanie.say("'I didn't name you Steve! Your manufacturer did you dummy!'");
      stephanie.ventriloquize("'Then give me a different name!'");
      stephanie.say("'Everybody is rude today! How about Roarke?'");


      dummy2.setName("Roarke");
      stephanie.useSpecialAction();
      stephanie.ventriloquize("'I like the new name " + dummy2.getName() + ". It's the most beautiful name in the world.'");
      stephanie.say("'I don't like it as much as Steve, but whatever. Good evening, " + dummy2.getName() + ".'");
      stephanie.ventriloquize("'Thank you!'");
      stephanie.say("'Look, Roarke. Everybody is laughing at us because you had to change your name.'");
      stephanie.ventriloquize("'They're not laughing at me, they're laughing at you because you're a bad ventriloquist!'");
      stephanie.say("'Fine! I'll drink water to prove myself! Roarke is alive and a dummy everyone!'");
      stephanie.drinkAndSpeak("'And there you have it everyone! Apparently I'm alive and a dummy!'");
    }
    public static void main(String [] args) {

    start();


}}
